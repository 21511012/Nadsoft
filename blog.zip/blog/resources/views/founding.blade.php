<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}" />

<link rel="stylesheet"href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="{{ asset('style.css') }}" />
  <link rel="stylesheet" href="{{ asset('js/style.js') }}" />

</head>
<body>
<header>
<div class="header">
<nav class="navbar ">

<div id="navbar">
<ul class="direction-rtl float-right">
<li><a href="#"><i class="logo"></i></a></li>
<li ><a href="#secHowWork" class="term1"> عن حملة</a></li>
<li ><a href="#secHowWork8"class="term2">اصدارات</a></li>
<li class="term3"><a href="#secHowWork10" class="term3">اخبار وتقارير</a></li>
<li class="term4"><a href="#secHowWork11"class="term4"> حملات</a></li>
<li class="term5"><a href="#secHowWork12" class="term5"> تواصل معنا</a></li>
<li class="term6">  <select class="form-control term6" name="languges">
<option><a href="#">En</a></option>
<option><a href="#">Ar</a></option>
</select>
</li>  
<li><a href="#"class="donate" ><span>تبرع</span></a></li>
<li><a href="#" class="share"><span>شارك معنا</span></a></li>



</ul>              


</div>
</nav>
</div>

</header>
<form method="post" enctype="multipart/form-data" id="main-form"> 
{{csrf_field()}}
<div class="container direction-rtl float-right found">
    <div class="row direction-rtl float-right">
        <div class="col-xs-12 col-sm-12 col-md-12 ">
            <span><a href="#"></a></span>
            <div class="text">تبرع</div>
        </div>
    </div>
</div>
<div class="container text-block">
<div class="row direction-rtl float-right">
    <div class="col-xs-12 col-sm-12 col-md-12 ">
        <p>
        ساعد حملة في حماية حرية التعبير و الحقوق الرقمية الفلسطينية أرسل تبرعاتك و<br>
         مساهمتك من خلال:
        </p>
    </div>
    </div>
</div>
<div class="container information direction-rtl float-right ">
<div class="row direction-rtl float-right">
<div class="card float-right">
<p>معلومات التبرع</p>

<div class="card-body ">
    <div class="choise">
    <div class="col-xs-12 col-sm-12 col-md-6 float-right direction-rtl">
     <h4>اختر نوع التبرع:</h4>   
    <label class="radios">
    <input type="radio"    name="radio1" value="مرة واحدة"checked="checked " class="r required"required="required">
    مرة واحدة  </label>
  <label class="radios space1">
     <input type="radio" class="required" name="radio1" value="شهري"required="required">
     شهري
  </label>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-6 float-right direction-rtl">
        <h4>اختر العملة:</h4>
    <label class="radios">
    <input type="radio" name="radio2" value="الدولار الأمريكي ($)"required="required" class="required">
    الدولار الأمريكي ($) 
 </label>
  <label class="radios space2">
     <input type="radio" name="radio2" value="الشيكل (₪)"required="required" class="required">
     الشيكل (₪)
  </label>
    </div>
    </div>
    <div class="choise-mony">
    <div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl">
     <h4 class="text">اختر مبلغ التبرع:</h4>
    <button type="button" class="btn btn-success">100$</button>
    <button type="button" class="btn btn-success">150$</button>
    <button type="button" class="btn btn-success">200$</button>
    <button type="button" class="btn btn-success">250$</button>
    <button type="button" class="btn btn-success">300$</button>
    
    <div class="input-text">
    <input type="text" name="amountfounded" placeholder="400$"required="required"class="required"> 
    <hr>

    </div>


    </div>
    </div>

    <div class="information-personal">
    <div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl">
        <h3>المعلومات الشخصية</h3>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-6 float-right direction-rtl information1">
    <div class="form-group">
    <label for="name">الاسم:</label>
    <input type="text" class="form-control required" name="nameCard" id="name" placeholder="الاسم كامل"required="required">
  </div>
  <div class="form-group">
      <label for="city">المدينة:</label>
      <select id="city" class="form-control required"required="required" name="city">
      <option value="عمان">عمان</option>
      </select>
  </div>
  <div class="form-group">
    <label for="email">البريد الالكتروني:</label>
    <input type="email" class="form-control required" required="required" name="emails"id="email" placeholder="user@gmail.com">
  </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-6 float-right direction-rtl information2">
    <div class="form-group">
      <label for="disten">البلد</label>
      <select id="disten" class="form-control required"required="required" name="town">
      <option value="الاردن">الاردن</option>
      </select>
  </div>

    <div class="form-group">
    <label for="address">العنوان:</label>
    <input type="text" class="form-control required"required="required" name="address"id="address" placeholder="عمان-ش.الاردن- عمارة ٦٧">
  </div>
 
  <div class="form-group">
    <label for="phone">رقم الهاتف:</label>
    <input type="tel" name="phone" class="form-control required"required="required" id="phone" placeholder="+967 999 999 99 99">
  </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl line" >
      <hr>
   </div>
        
    </div>

    <div class="information-pay">
    <div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl">
        <h3>معلومات الدفع</h3>
        <h4>اختر طريقة الدفع:</h4>
    <label class="radios pay-one">
    <input type="radio" name="typecoin"required="required" class="required" value="بطاقة الاعتماد">
    <span>بطاقة الاعتماد</span> 
    </label>
  <label class="radios pay-two">
     <input type="radio"required="required" class="required" name="typecoin" value="Paypal">
     <span>Paypal</span>
      </label>
      
    </div>    </div>

    <form method="post" enctype="multipart/form-data" id="information-pay"> 
    {{csrf_field()}}

    <div class="information-pay2 float-right direction-rtl">
    <div class="col-xs-12 col-sm-12 col-md-5 float-right direction-rtl information1">
    <div class="form-group">
    <label for="card">اسم حامل البطاقة:</label>
    <input type="text" required="required" class="form-control required" name="names" id="card" placeholder="Card holder name">
  </div>
  
  <div class="form-group top30">
    <label for="date-finished">تاريخ انتهاء البطاقة:</label>
    <input type="date"required="required" class="form-control required" name="dates" id="date-finished"  placeholder="23/21">
  </div>

    </div>
    <div class="col-xs-12 col-sm-12 col-md-2 float-right direction-rtl btn-pay">
    <button type="submit" class="btn sendcards">تم</button>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-5 float-right direction-rtl information2">
   
    <div class="form-group">
    <label for="number">رقم البطاقة:</label>
    <input type="text"required="required" class="form-control required" name="cardnumber" id="address" placeholder="123 456 665 909 009">
  </div>
 
  <div class="form-group top30">
    <label for="cvc">CVC</label>
    <input type="text"required="required" class="form-control required" name="cvc" id="cvc" placeholder="874">
  </div>
    </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 btn-found float-right direction-rtl">
    <button type="submit" class="btn found">تبرع</button>

    </div>



   
    
</div>
</div>
</div>
</div>
</form>
</div>
</form>

<div class="join-list float-right direction-rtl">
<div class="row">
    <div class="card">
<div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl">
    <h2>انضم لقائمة النشر</h2>
    <p>لتكن جزء من التكافل المجتمعي وتنضم لفريق النشر في حملة</p>

    <div class="shape">
        <form method="post" enctype="multipart/form-data" id="send-join"> 
        {{csrf_field()}}
        <input type="text" required="required" name="name" class="name required" placeholder="الاسم">
        <input type="email" required="required" class="email required" name="email" placeholder="البريد الالكتروني">
        <button type="submit" class="btn sendjoin">ارسل انضمامي</button>
        </form>

    </div>
</div> 
</div>
</div>
</div>

<footer>
<div class="footer float-right direction-rtl">
    <div class="row">
       <div class="col-xs-12 col-sm-12 col-md-12 float-right direction-rtl">
           <div class="image-footer">
           <img class="img1"src="images/Path 5521.svg">
           <img class="img2"src="images/Mask Group 3@2x.png">
           <img class="img3"src="images/Path 5522 (1).svg">


           </div>
           <div class="footer-end">
               <a href="#">الصفحة الرئيسية</a>
               <a href="#">عن حملة</a>
               <a href="#">تواصل معنا</a>
               <a href="#">حملات</a>
               <a href="#">اصدارات</a>
               <a href="#">اخبار وتقارير</a>
               <a href="#" class="found">تبرع</a>
               <a href="#" class="share">شارك معنا</a>

           </div>
           <div class="share-icon">
               <span class="facebook"><a href="#"><img class="img1"src="images/facebook.svg"></a></span>
               <span class="twitter"><a href="#"><img class="img1"src="images/twitter.svg"></a></span>
               <span class="logo"><a href="#"><img class="img1"src="images/logo.svg"></a></span>
               <span class="linkedin"><a href="#"><img class="img1"src="images/linkedin.svg"></a></span>
               <span><a href="#"><img class="img1"src="images/mail.svg"></a></span>

           </div>
           <div class="copy">
               <span class="right">
                   جميع الحقوق محفوظة لموقع <span class="site"> حملة </span><span class="c"> &#169; </span>2020
            
            </span>
            <span><a href="#"><img class="img1"src="images/Group 35.svg"></a></span>

           </div>
       </div>
    </div>
</div>
</footer>


</body>
<script>
   
$(".sendjoin").click(function(stay){
    stay.preventDefault()
    var formData = new FormData($('form')[0]);

    var d = $("#send-join,#pay-information,#main-form").serializeArray();
     $.each(d, function(i, field){
      formData.append(field.name, field.value);//a[field.name] = field.value;
    
    });
    console.log(formData)
      $.ajax({
          type: 'POST',
          url: "{{ url('/sendjoin') }}",
          data:formData,
          processData: false,
          contentType: false, // here $(this) refers to the ajax object not form
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function (data) {
             console.log(data)
          },
      });

    
});

$(".sendcards").click(function(stay){
    stay.preventDefault()
    var formData = new FormData($('form')[0]);

    var d = $("#send-join,#pay-information,#main-form").serializeArray();
     $.each(d, function(i, field){
      formData.append(field.name, field.value);//a[field.name] = field.value;
    
    });
    console.log(formData)
      $.ajax({
          type: 'POST',
          url: "{{ url('/sendcard') }}",
          data:formData,
          processData: false,
          contentType: false, // here $(this) refers to the ajax object not form
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function (data) {
             console.log(data)
          },
      });

    
});
$(".found").click(function(stay){
    stay.preventDefault()
    var formData = new FormData($('form')[0]);

    var d = $("#send-join,#pay-information,#main-form").serializeArray();
     $.each(d, function(i, field){
      formData.append(field.name, field.value);//a[field.name] = field.value;
    
    });
    console.log(formData)
      $.ajax({
          type: 'POST',
          url: "{{ url('/personalInformation') }}",
          data:formData,
          processData: false,
          contentType: false, // here $(this) refers to the ajax object not form
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function (data) {
             console.log(data)
          },
      });

    
});
</script>
</html>