<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SebastianBergmann\Environment\Console;

class HomeController extends Controller
{
    public function join(Request $request){
        DB::table('social-solidarity')->insert([
             'name' => $request->name ,//$data['date'],
              'email' => $request->email,
              ]); 
		return response()->json( ['success'=> true] );
    }


    public function card(Request $request){
        session(['id' => (string)$request->cardnumber]);

        DB::table('information-pay')->insert([
             'type-coin' => $request->typecoin ,//$data['date'],
              'name' => $request->names,
              'dates' => $request->dates ,//$data['date'],
              'card-number' => $request->cardnumber,
              'cvc' => $request->cvc ,//$data['date'],

            
              ]); 

             

		return response()->json( ['success'=> true] );
    }

    public function information(Request $request){
        $post=DB::table('information-pay')
        ->select('id')
        ->where('card-number', '=', (int)($request->session()->get('id')))
        ->get();

        DB::table('information-founding')->insert([
             'pay-way' => $request->radio1	 ,//$data['date'],
              'amount-founded'=> $request->amountfounded,
              'name' => $request->nameCard ,//$data['date'],
              'city' => $request->city,
              'email' => $request->emails,
              'town' => $request->town,
              'address' => $request->address,
              'phone' => $request->phone ,//$data['date'],
              'id-fk' =>$post[0]->id ,
              'coin'=>$request->radio2,

              ]); 


		return response()->json((int)($request->session()->get('id')) );
    }




    
}
